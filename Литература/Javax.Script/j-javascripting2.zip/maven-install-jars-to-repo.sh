#!/bin/sh

GROUP_ID=net.java.dev.scripting
VERSION=1.0
GROOVY_JAR=./lib/script-engines/groovy-engine-1.0.jar
JRUBY_JAR=./lib/script-engines/jruby-engine-1.0.jar

echo Installing groovy-engine.jar to local Maven repository
mvn install:install-file -DgroupId=$GROUP_ID -DartifactId=groovy-engine \
    -Dversion=$VERSION -Dpackaging=jar -Dfile=$GROOVY_JAR

echo Installing jruby-engine.jar to local Maven repository
mvn install:install-file -DgroupId=$GROUP_ID -DartifactId=jruby-engine \
    -Dversion=$VERSION -Dpackaging=jar -Dfile=$JRUBY_JAR
