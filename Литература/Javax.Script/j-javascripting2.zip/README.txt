--------------------------------------------
IBM developerWorks / Java technology
Part 2: Invoke Dynamic Languages Dynamically
By Tom McQueeney
http://mcqueeney.com/
tom.mcqueeney@gmail.com
--------------------------------------------

These are instructions for running the ScriptMortgageQualifierRunner class.
This class demonstrates how you can dynamically invoke scripts written in
dynamic languages in order to extend the functionality of a Java application.

-----
ANT

To run the demonstration application with Ant, open a shell and switch to 
the directory where this README.txt file lives. Type:

    ant run
    
This assumes you have Apache Ant (http://ant.apache.org/) installed and on
your command path.

-----
MAVEN

For Maven2 users, you'll first need to install the Groovy and JRuby script
engines into your local Maven repository. The java.net scripting project
that hosts the script engines does not provide a Maven repo. There is a
shell script in this directory to install the JARs into your local repository,
maven-install-jars-to-repo.bat for Windows users and 
maven-install-jars-to-repo.sh for Unix/Linux/OS X/Cygwin users. Windows users
can run the script with the command:

    maven-install-jars-to-repo
      
while *nix users will need to run the file through a Bourne/Bash shell using:

    sh maven-install-jars-to-repo.sh
    
(Unix users also can chmod the file to make it executable.)

Once the JARs are installed in your local repository, run the "package" phase
to create the executable JAR file for this demo code:

    mvn package
    
Packaging the project creates the file scripting-demo-1.0.jar in the target 
subdirectory. You can now run the executable JAR with the command:

    java -jar target\scripting-demo-1.0.jar src\main\scripts\mortgage-products
    
*nix users will need to change the direction of the slashes. (But you probably 
already know that.)

The program's argument is the directory containing the Groovy, Ruby and 
JavaScript scripts. 

Note that the classpath set inside the executable JAR file uses relative paths
to find the dependent JAR files in the lib directory. The relative paths assume
the file is being run from the target subdirectory.

-----
PROBLEMS?

Something not working? Let me know and I'll try to help. My email address is 
above. If something appears broken, ensure you have either Sun's or BEA's 
Java 1.6 JDK installed and that's the one being used by Ant/Maven, and ensure
Ant or Maven2 is correctly installed and configured.
 
Things you can check:

o Maven users: Did you run the maven-install-jars-to-repo script?
o Run "java -version" to ensure you see a 1.6 version
o Run "echo %JAVA_HOME%" (windows) or "echo $JAVA_HOME" (*nix) to check your 
  JAVA_HOME environment variable.
o Run "ant -version" to ensure Ant is installed
  OR:
o Run "mvn --version" to ensure Maven2 is installed
o Did you move the scripting-demo-1.0.jar file from the target directory?
  If so, put it back and try again.

