package com.mcqueeney.demo;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import junit.framework.TestCase;

/**
 * Tests whether Groovy, JavaScript, and JRuby allow a top-level script 
 * to return from script processing before the end of the script text.
 */
public class ScriptReturnTest extends TestCase {

    private ScriptEngineManager scriptEngineMgr;

    public void setUp() {
        scriptEngineMgr = new ScriptEngineManager();
    }
    
    /** Groovy permits top-level returns. A nice feature. */
    public void testGroovyReturn() {
        ScriptEngine groovyEngine = scriptEngineMgr.getEngineByName("groovy");
        groovyEngine.put("x", Integer.valueOf(5));
        String groovyScript = 
            "assert x == 5;" +
            "x = 10;" +
            "return;" + // Groovy permits "return" statement at top level!
            "x = 15";
        try {
            groovyEngine.eval(groovyScript);
            assertEquals(Integer.valueOf(10), groovyEngine.get("x"));
        } catch (ScriptException e) {
            fail("Groovy script failed: " + e.getMessage());
        }
    }

    /** A top-level return statement in JavaScript is illegal. */
    public void testJavaScriptReturn() {
        ScriptEngine jsEngine = scriptEngineMgr.getEngineByName("JavaScript");
        jsEngine.put("x", Integer.valueOf(5));
        String javaScript = 
            "if (x != 5) {" +
            "    throw 'x is not 5'" +
            "}" +
            "return;" + // Top-level return is illegal.
            "x = 10";
        try {
            jsEngine.eval(javaScript);
            fail(
                "Top-level return stmt in JavaScript should have caused" +
                " syntax error"
            );
        } catch (ScriptException e) {
            // Exception caused by invalid return statement.
            assertTrue(e.getMessage().contains("invalid return"));
        }
    }

    /** You can return from a function, but you have to *call* the function. */ 
    public void testJavaScriptFunctionReturn() throws ScriptException {
        ScriptEngine jsEngine = scriptEngineMgr.getEngineByName("JavaScript");
        jsEngine.put("x", Integer.valueOf(5));
        
        // Returning from a function is OK, but eval'ing a function won't
        // execute it. That has to be done in a separate function call.
        String javaScript =
            "function testing() {" +
            "    if (x != 5) {" +
            "        throw 'x is not 5'" +
            "    }" +
            "    x = 10;" +
            "    return;" + // Function return is syntactically correct.
            "    x = 15" +
            "}";
        
        jsEngine.eval(javaScript);
        assertEquals( // Assertion true because function declared but not called.
            Integer.valueOf(5), jsEngine.get("x")
        );
    }

    /** Return from function works here because we call the function. */ 
    public void testExplicitFunctionCallReturn() throws ScriptException {
        ScriptEngine jsEngine = scriptEngineMgr.getEngineByName("JavaScript");
        jsEngine.put("x", Integer.valueOf(5));

        // Same script function definition as above test.
        String javaScript =
            "function testing() {" +
            "    if (x != 5) {" +
            "        throw 'x is not 5'" +
            "    }" +
            "    x = 10;" +
            "    return;" + // Function return is syntactically correct.
            "    x = 15" +
            "}";

        jsEngine.eval(javaScript);
        assertEquals(
            "x is still 5 because the function hasn't been called yet",
            Integer.valueOf(5), Integer.valueOf(jsEngine.get("x").toString())
        );
        
        jsEngine.eval("testing()");
        // This assertion will be true, but we had to call the function.
        assertEquals(
            "Calling function separately didn't set x to 10 as expected",
            Double.valueOf(10.0), Double.valueOf(jsEngine.get("x").toString())
        );
    }

    /** Ruby doesn't permit return statement at top-level (Object) context. */
    public void testRubyReturn() {
        ScriptEngine rubyEngine = scriptEngineMgr.getEngineByName("jruby");
        rubyEngine.put("x", Integer.valueOf(5));
        String rubyScript = 
            "raise 'x is not 5' if ($x != 5);" +
            "$x = 10;" +
            "return;" + // Top-level return allowed in Ruby? (No)
            "puts 'Got past return statement';" +
            "$x = 15;";
        try {
            assertEquals(Integer.valueOf(5), rubyEngine.get("x"));
            rubyEngine.eval(rubyScript);
            fail("Unexpected result: return statement actually works!");
        } catch (ScriptException e) {
            // Expected. Check to ensure we got an "unexpected return" error.
            Throwable t = e.getCause();
            if (t instanceof org.jruby.exceptions.RaiseException) {
                org.jruby.exceptions.RaiseException re = 
                    (org.jruby.exceptions.RaiseException) t;
                assertEquals(
                    "RaiseException not expected 'unexpected return' error",
                    "unexpected return", 
                    re.getException().asString().toString()
                );
            } else {
                fail("Ruby script failed unexpectedly: " + e.getMessage());
            }
        }
    }

    /** JRuby doesn't permit exit statement at top-level context. */
    public void testRubyExit() {
        ScriptEngine rubyEngine = scriptEngineMgr.getEngineByName("jruby");
        rubyEngine.put("x", Integer.valueOf(5));
        String rubyScript = 
            "raise 'x is not 5' if ($x != 5);" +
            "$x = 10;" +
            "exit;" + // Top-level exit allowed in Ruby? (No)
            "puts 'Got past exit statement';" +
            "$x = 15;";
        try {
            assertEquals(Integer.valueOf(5), rubyEngine.get("x"));
            rubyEngine.eval(rubyScript);
            fail("Unexpected result: exit statement actually works!");
        } catch (ScriptException e) {
            // Expected because 'exit' statement causes a JRuby RaiseException.
            Throwable t = e.getCause();
            assertTrue(
                "A ScriptException other than a RaiseException thrown",
                t instanceof org.jruby.exceptions.RaiseException
            );
        }
    }

    public void testRubyBreak() throws ScriptException {
        ScriptEngine rubyEngine = scriptEngineMgr.getEngineByName("jruby");
        rubyEngine.put("x", Integer.valueOf(5));
        String rubyScript = 
            "raise 'x is not 5' if ($x != 5);" +
            "1.times do;" +
            "    $x = 10;" +
            "    break;" +
            "    puts 'Got past exit statement';" +
            "    $x = 15;" +
            "end";
        assertEquals(Integer.valueOf(5), rubyEngine.get("x"));
        rubyEngine.eval(rubyScript);
        assertEquals(Long.valueOf(10), rubyEngine.get("x"));
    }
}