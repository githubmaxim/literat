package com.mcqueeney.demo;

import com.shakygroundfinancial.MortgageQualificationResult;
import com.shakygroundfinancial.ScriptMortgageQualifier;
import com.shakygroundfinancial.entities.Borrower;
import com.shakygroundfinancial.entities.Loan;
import com.shakygroundfinancial.entities.Property;

import java.io.File;
import java.io.FileNotFoundException;

import javax.script.ScriptException;

import junit.framework.TestCase;

/**
 * Test to exercise the logic in ScriptMortgageQualifier to ensure it can run
 * test rules scripts in JavaScript, Groovy and Ruby.
 */
public class ScriptMortgageQualifierTest extends TestCase {

    public static final String RUBY_TEST_SCRIPT = 
        "src/test/scripts/mortgage-rules/MortgageQualifierTestScript.rb";
    public static final String GROOVY_TEST_SCRIPT = 
        "src/test/scripts/mortgage-rules/MortgageQualifierTestScript.groovy";
    public static final String JAVASCRIPT_TEST_SCRIPT = 
        "src/test/scripts/mortgage-rules/MortgageQualifierTestScript.js";

    Borrower borrower = new Borrower();
    Property property = new Property();
    Loan loan = new Loan();
    
    public static final double TOLERANCE = 0.00000001;
    
    public void setUp() {
        borrower.setName("Unit Test");
    }
    
    public void testQualifyMortgageBad() {
        ScriptMortgageQualifier mortgageQualifier = new ScriptMortgageQualifier();
        
        // Test a file name with no script engine
        File badFile = new File("test-noengine.blahblah");
        try {
            mortgageQualifier.qualifyMortgage(borrower, property, loan, badFile);
            fail("Calling with bad file extension should throw IAE");
        } catch (IllegalArgumentException iae) {
            // Pass. Expected exception.
        } catch (FileNotFoundException fnfe) {
            fail("Should have thrown IllegalArgumentException instead");
        } catch (ScriptException se) {
            fail("Script should not have caused script exception");
        }

        // Test a JavaScript file that doesn't exist.
        File noSuchFile = new File("test-nofile.js");
        try {
            mortgageQualifier.qualifyMortgage(borrower, property, loan, noSuchFile);
            fail("Calling with nonexistent file should throw FNF exception");
        } catch (FileNotFoundException fnfe) {
            // Pass. Expected exception.
        } catch (ScriptException e) {
            fail("Script should not have existed");
        }
    }

    public void testQualifyMortgageJavaScript() 
      throws FileNotFoundException, ScriptException 
    {
        ScriptMortgageQualifier mortgageQualifier = new ScriptMortgageQualifier();

        // Test a good JavaScript mortgage qualification file.
        File jsGoodFile = new File(JAVASCRIPT_TEST_SCRIPT);
        MortgageQualificationResult result = mortgageQualifier.qualifyMortgage(
            borrower, property, loan, jsGoodFile
        );
        assertTrue(
            "Qualification should have been true", result.isQualified()
        );
        assertEquals(
            "Wrong interest rate returned",
            0.10, result.getInterestRate(), TOLERANCE
        );
        assertEquals(
            "Wrong qualification message", "Success!", result.getMessage()
        );
        
        assertEquals(
            "Product name unexpected",
            "Everyone Qualifies Mortgage", result.getProductName()
        );
    }

    public void testQualifyMortgageGroovy()
      throws FileNotFoundException, ScriptException
      {
        ScriptMortgageQualifier mortgageQualifier = new ScriptMortgageQualifier();

        // Test a good Groovy mortgage qualification file.
        File groovyGoodFile = new File(GROOVY_TEST_SCRIPT);
        MortgageQualificationResult result = mortgageQualifier.qualifyMortgage(
                borrower, property, loan, groovyGoodFile
        );
        assertTrue(
            "Qualification should have been true", result.isQualified()
        );
        
        assertEquals(
            "Wrong interest rate returned",
            0.11, result.getInterestRate(), TOLERANCE
        );
        assertEquals(
            "Wrong qualification message", "GroovySuccess!", result.getMessage()
        );
        
        assertEquals(
            "Product name unexpected",
            "Groovy: Everyone Qualifies", result.getProductName()
        );
    }
    
    public void testQualifyMortgageRuby() throws ScriptException, FileNotFoundException {
        ScriptMortgageQualifier mortgageQualifier = new ScriptMortgageQualifier();
    
        // Test a good Ruby mortgage qualification file.
        File rubyGoodFile = new File(RUBY_TEST_SCRIPT);
        MortgageQualificationResult result = mortgageQualifier.qualifyMortgage(
                borrower, property, loan, rubyGoodFile
        );
        assertTrue(
            "Qualification should have been true", result.isQualified()
        );
        assertEquals(
            "Wrong interest rate returned",
            0.12, result.getInterestRate(), TOLERANCE
        );
        assertEquals(
            "Wrong qualification message", "RubySuccess!", result.getMessage()
        );
        
        assertEquals(
            "Product name unexpected",
            "Ruby: Everyone Qualifies", result.getProductName()
        );
    }

}
