$result.product_name = "Ruby: Everyone Qualifies"

# These will work, too:
# $result.setInterestRate 0.12
# $result.set_interest_rate 0.12
# $result.interestRate = 0.12
$result.interest_rate = 0.12

$result.qualified = true
$result.message = 'RubySuccess!'
