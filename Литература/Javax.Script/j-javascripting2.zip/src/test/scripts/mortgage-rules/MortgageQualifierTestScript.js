result.productName = "Everyone Qualifies Mortgage"

// loan.setInterestRate(new java.math.BigDecimal('0.10'))
result.setInterestRate(0.10)
result.qualified = true
result.message = 'Success!'
