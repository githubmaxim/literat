result.productName = "Groovy: Everyone Qualifies"

result.interestRate = 0.11
result.qualified = true
result.message = 'GroovySuccess!'
