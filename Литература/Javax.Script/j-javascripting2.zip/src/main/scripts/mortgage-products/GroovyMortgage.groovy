/*
   This Groovy script defines the "Groovy Mortgage" product.
   This product is relaxed in its requirements of borrowers.
   There is a higher interest rate to make up for the looser standard.
   All borrowers will be approved if their credit history is good, they can
   make a downpayment of at least 5%, and they either earn more than 
   $2,000/month or have a net worth (assets minus liabilities) of $25,000.
*/

// Our product name.
result.productName = 'Groovy Mortgage'

//  Check for the minimum income and net worth
def netWorth = borrower.totalAssets - borrower.totalLiabilities
if (borrower.monthlyIncome < 2000 && netWorth < 25000) {
    scriptExit.withMessage "Low monthly income of ${borrower.monthlyIncome}" +
         ' requires a net worth of at least $25,000.'
}

def downPaymentPercent = loan.downPayment / property.salesPrice * 100
if (downPaymentPercent < 5) {
    scriptExit.withMessage 'Down payment of ' +
        "${String.format('%1$.2f', downPaymentPercent)}% is insufficient." +
        ' 5% minimum required.'
}
if (borrower.creditScore < 600) {
    scriptExit.withMessage 'Credit score of 600 required.'
}

// Everyone else qualifies. Find interest rate based on downpayment percent.
result.qualified = true
result.message = 'Groovy! You qualify.'

switch (downPaymentPercent) {
    case 0..5:   result.interestRate = 0.08; break
    case 6..10:  result.interestRate = 0.075; break
    case 11..15: result.interestRate = 0.07; break
    case 16..20: result.interestRate = 0.065; break
    default:     result.interestRate = 0.06; break
}
