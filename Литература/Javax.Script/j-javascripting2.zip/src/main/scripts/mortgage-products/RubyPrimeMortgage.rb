# This Ruby script defines the "Ruby Mortgage" product.
# It is intended for premium borrowers with its low interest rate
# and 20% down payment requirement.

# Our product name 
$result.product_name = 'Ruby Mortgage'

# Borrowers with poor credit do not qualify.
if $borrower.credit_score < 700
    $scriptExit.with_message "Credit score of #{$borrower.credit_score}" +
        " is lower than 700 minimum."
end

$scriptExit.with_message 'No bankruptcies allowed' if $borrower.hasDeclaredBankruptcy
 
# Check other negatives
down_payment_percent = $loan.down_payment / $property.sales_price * 100
if down_payment_percent < 20
    $scriptExit.with_message 'Down payment must be at least 20% of sale price.'
end

# Borrower qualifies. Determine interest rate of loan
$result.message = "Qualified!"
$result.qualified = true

# Give the best interest rate to the best credit risks.
if $borrower.credit_score > 750 || down_payment_percent > 25
    $result.interestRate = 0.06
elsif $borrower.credit_score > 700 && $borrower.totalAssets > 100000
    $result.interestRate = 0.062
else
    $result.interestRate = 0.065
end
