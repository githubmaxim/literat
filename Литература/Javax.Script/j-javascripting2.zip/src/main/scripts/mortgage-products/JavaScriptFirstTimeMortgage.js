/**
 * This script defines the "JavaScript FirstTime Mortgage" product.
 * It is a government-sponsored mortgage intended for low-income, first-time 
 * home buyers without a lot of assets who intend to live in the home.
 * Bankruptcies and bad (but not terrible!) credit are OK.
 */

result.productName = 'JavaScript FirstTime Mortgage'

if (!borrower.intendsToOccupy) {
    result.message = 'This mortgage is not intended for investors.'
    scriptExit.noMessage()
}
if (!borrower.firstTimeBuyer) {
    result.message = 'Only first-time home buyers qualify for this mortgage.'
    scriptExit.noMessage()
}
if (borrower.monthlyIncome > 4000) {
    result.message = 'Monthly salary of $' + borrower.monthlyIncome +
        ' exceeds the $4,000 maximum.'
    scriptExit.noMessage()
}
if (borrower.creditScore < 500) {
    result.message = 'Your credit score of ' + borrower.creditScore + 
        ' does not meet the 500 requirement.'
    scriptExit.noMessage()
}

// Qualifies. Determine interest rate based on loan amount and credit score.
result.qualified = true
result.message = 'Congratulations, you qualify.'

if (loan.loanAmount > 450000) {
    result.interestRate = 0.08 // Big loans and poor credit require higher rate.
} else if (borrower.creditScore < 550) {
    result.interestRate = 0.08
} else if (borrower.creditScore < 600) {
    result.interestRate = 0.07
} else if (borrower.creditScore < 700) {
    result.interestRate = 0.065
} else { // Good credit gets best rate.
    result.interestRate = 0.06
}    
