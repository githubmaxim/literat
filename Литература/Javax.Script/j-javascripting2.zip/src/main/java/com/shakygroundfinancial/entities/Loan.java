package com.shakygroundfinancial.entities;

/**
 * A value object containing basic information about a mortgage loan: amount,
 * term and down payment.
 */
public class Loan {

    private double loanAmount;
    private int termMonths;
    private double downPayment;
    
    
    public double getDownPayment() {
        return downPayment;
    }
    public Loan setDownPayment(double downPayment) {
        this.downPayment = downPayment;
        return this;
    }
    public double getLoanAmount() {
        return loanAmount;
    }
    public Loan setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
        return this;
    }
    public int getTermMonths() {
        return termMonths;
    }
    public Loan setTermMonths(int termMonths) {
        this.termMonths = termMonths;
        return this;
    }
    
}
