package com.shakygroundfinancial.entities;

public class Property {

    private String streetAddress;
    private String city;
    private String state;
    private String postalCode;
    private int yearBuilt;
    private int lastSoldYear;
    private double salesPrice;
    private double lastSoldPrice;
    private double costOfLand;
    private double appraisedValue;

    public double getAppraisedValue() {
        return appraisedValue;
    }
    public Property setAppraisedValue(double appraisedValue) {
        this.appraisedValue = appraisedValue;
        return this;
    }
    public String getCity() {
        return city;
    }
    public Property setCity(String city) {
        this.city = city;
        return this;
    }
    public double getCostOfLand() {
        return costOfLand;
    }
    public Property setCostOfLand(double costOfLand) {
        this.costOfLand = costOfLand;
        return this;
    }
    public double getLastSoldPrice() {
        return lastSoldPrice;
    }
    public Property setLastSoldPrice(double lastSoldPrice) {
        this.lastSoldPrice = lastSoldPrice;
        return this;
    }
    public int getLastSoldYear() {
        return lastSoldYear;
    }
    public Property setLastSoldYear(int lastSoldYear) {
        this.lastSoldYear = lastSoldYear;
        return this;
    }
    public String getPostalCode() {
        return postalCode;
    }
    public Property setPostalCode(String postalCode) {
        this.postalCode = postalCode;
        return this;
    }
    public String getState() {
        return state;
    }
    public Property setState(String state) {
        this.state = state;
        return this;
    }
    public String getStreetAddress() {
        return streetAddress;
    }
    public Property setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
        return this;
    }
    public int getYearBuilt() {
        return yearBuilt;
    }
    public Property setYearBuilt(int yearBuilt) {
        this.yearBuilt = yearBuilt;
        return this;
    }
    public double getSalesPrice() {
        return salesPrice;
    }
    public Property setSalesPrice(double salesPrice) {
        this.salesPrice = salesPrice;
        return this;
    }

}
