package com.shakygroundfinancial.entities;

public class Borrower {

    private String name;
    private String ssn;
    private double totalAssets;
    private double totalLiabilities;
    private double monthlyIncome;
    private double monthlyExpenses;
    private int creditScore;
    private boolean intendsToOccupy;
    private boolean firstTimeBuyer;
    private boolean hasDeclaredBankruptcy;
    public int getCreditScore() {
        return creditScore;
    }
    public Borrower setCreditScore(int creditScore) {
        this.creditScore = creditScore;
        return this;
    }
    public boolean isFirstTimeBuyer() {
        return firstTimeBuyer;
    }
    public Borrower setFirstTimeBuyer(boolean firstTimeBuyer) {
        this.firstTimeBuyer = firstTimeBuyer;
        return this;
    }
    public boolean isHasDeclaredBankruptcy() {
        return hasDeclaredBankruptcy;
    }
    public Borrower setHasDeclaredBankruptcy(boolean hasDeclaredBankruptcy) {
        this.hasDeclaredBankruptcy = hasDeclaredBankruptcy;
        return this;
    }
    public boolean isIntendsToOccupy() {
        return intendsToOccupy;
    }
    public Borrower setIntendsToOccupy(boolean intendsToOccupy) {
        this.intendsToOccupy = intendsToOccupy;
        return this;
    }
    public double getMonthlyExpenses() {
        return monthlyExpenses;
    }
    public Borrower setMonthlyExpenses(double monthlyExpenses) {
        this.monthlyExpenses = monthlyExpenses;
        return this;
    }
    public double getMonthlyIncome() {
        return monthlyIncome;
    }
    public Borrower setMonthlyIncome(double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
        return this;
    }
    public String getName() {
        return name;
    }
    public Borrower setName(String name) {
        this.name = name;
        return this;
    }
    public String getSsn() {
        return ssn;
    }
    public Borrower setSsn(String ssn) {
        this.ssn = ssn;
        return this;
    }
    public double getTotalAssets() {
        return totalAssets;
    }
    public Borrower setTotalAssets(double totalAssets) {
        this.totalAssets = totalAssets;
        return this;
    }
    public double getTotalLiabilities() {
        return totalLiabilities;
    }
    public Borrower setTotalLiabilities(double totalLiabilities) {
        this.totalLiabilities = totalLiabilities;
        return this;
    }
}
