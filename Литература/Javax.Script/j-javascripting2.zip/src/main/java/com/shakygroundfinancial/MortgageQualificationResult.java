package com.shakygroundfinancial;

/**
 * Represents the result of running rules to determine mortgage product
 * eligibility.
 */
public class MortgageQualificationResult {
    private boolean qualified;
    private double interestRate;
    private String message;
    private String productName;
    
    
    public boolean isQualified() {
        return qualified;
    }
    public void setQualified(boolean qualified) {
        this.qualified = qualified;
    }

    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public double getInterestRate() {
        return interestRate;
    }
    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }
}
