package com.shakygroundfinancial;

import com.shakygroundfinancial.entities.Borrower;
import com.shakygroundfinancial.entities.Loan;
import com.shakygroundfinancial.entities.Property;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;

import javax.script.ScriptException;

/**
 * A class to run the ScriptMortgageQualifier class by supplying it with sample
 * borrower, loan, and property objects, as well as files containing the scripts
 * that represent mortgage products. This class demonstrates the Java scripting
 * API's ability to dynamically invoke dynamic languages. It runs the scripts to
 * determine what types of home-loan mortgage products a set of contrived
 * borrowers qualifies for.
 * <p>
 * The products and rules for product qualifications are contained in external
 * script files written in JavaScript, Groovy and Ruby. The script files are
 * found and loaded dynamically (at runtime) once a minute to demonstrate the
 * ability for rules and products to change without having to restart the
 * application.
 */
public class ScriptMortgageQualifierRunner {

    private static File scriptDirectory;

    private static Borrower goodBorrower = createGoodBorrower();
    private static Borrower averageBorrower = createAverageBorrower();
    private static Borrower investorBorrower = createInvestorBorrower();
    private static Borrower riskyBorrower = createRiskyBorrower();
    private static Property property = createProperty();
    private static Loan loan = createLoan();

    /**
     * Main method to create a File for the directory name on the command line,
     * then call the run method if that directory exists.
     */
    public static void main(String[] args) {
        if (args.length > 0 && args[0].contains("-help")) {
            printUsageAndExit();
        }
        String dirName;
        if (args.length == 0) {
            dirName = "."; // Current directory.
        } else {
            dirName = args[0];
        }

        scriptDirectory = new File(dirName);
        if (!scriptDirectory.exists() || !scriptDirectory.isDirectory()) {
            printUsageAndExit();
        }

        run();
    }
    
    /**
     * Determines mortgage-loan qualification status for three test borrowers by
     * processing all script files in the given directory. Each script will
     * determine whether the given borrower is qualified for a particular mortgage
     * type.
     */
    public static void run() {
        ScriptMortgageQualifier mortgageQualifier = new ScriptMortgageQualifier();
        
        for(;;) { // Requires Ctrl-C to exit
            runQualifications(mortgageQualifier, goodBorrower, loan, property);
            runQualifications(mortgageQualifier, averageBorrower, loan, property);
            
            loan.setDownPayment(30000.0); // Reduce down payment to 10%
            runQualifications(mortgageQualifier, investorBorrower, loan, property);
            
            loan.setDownPayment(10000.0); // Reduce down payment to 3 1/3% 
            runQualifications(mortgageQualifier, riskyBorrower, loan, property);
        
            waitOneMinute();
        }
    }

    /**
     * Reads all script files in the scriptDirectory and runs them with this
     * borrower's information to see if he/she qualifies for each mortgage
     * product.
     */
    private static void runQualifications(
        ScriptMortgageQualifier mortgageQualifier, 
        Borrower borrower, 
        Loan loan, 
        Property property
    ) {
        for (File scriptFile : getScriptFiles(scriptDirectory)) {
            // Print info about the borrower, loan and property.
            System.out.println("Processing file: " + scriptFile.getName());
            System.out.println("  Borrower: " + borrower.getName());
            System.out.println("  Credit score: " + borrower.getCreditScore());
            System.out.println("  Sales price: " + property.getSalesPrice());
            System.out.println("  Down payment: " + loan.getDownPayment());

            MortgageQualificationResult result = null; 
            try {
                // Run the script rules for this borrower on the loan product.
                result = mortgageQualifier.qualifyMortgage(
                    borrower, property, loan, scriptFile
                );
            } catch (FileNotFoundException fnfe) {
                System.out.println(
                    "Can't read script file: " + fnfe.getMessage()
                );
            } catch (IllegalArgumentException e) {
                System.out.println(
                    "No script engine available to handle file: " + 
                    scriptFile.getName()
                );
            } catch (ScriptException e) {
                System.out.println(
                    "Script '" + scriptFile.getName() + 
                    "' encountered an error: " + e.getMessage()
                );
            }

            if (result == null) continue; // Must have hit exception.

            // Print results.
            System.out.println(
                "* Mortgage product: " + result.getProductName() +
                ", Qualified? " + result.isQualified() +
                "\n* Interest rate: " + result.getInterestRate() +
                "\n* Message: " + result.getMessage()
            );
            System.out.println();
        }
    }

    /** Returns files with a '.' other than as the first or last character. */
    private static File[] getScriptFiles(File directory) {
        return directory.listFiles(new FilenameFilter() {
            public boolean accept(File dir, String name) {
                int indexOfDot = name.indexOf('.');
                // Ignore files w/o a dot, or with dot as first or last char.
                if (indexOfDot < 1 || indexOfDot == (name.length() - 1)) {
                    return false;
                } else {
                    return true;
                }
            }
        });
    }

    private static void waitOneMinute() {
        System.out.println(
            "\nSleeping for one minute before reprocessing files." +
            "\nUse Ctrl-C to exit..."
        );
        System.out.flush();
        try {
            Thread.sleep(1000 * 60);
        } catch (InterruptedException e) {
            System.exit(1);
        }
    }

    /** Creates and returns a sample mortgage loan of $300,000 */
    private static Loan createLoan() {
        Loan loan = new Loan();
        loan
            .setLoanAmount(240000) // $240,000
            .setDownPayment(60000) // $60,000 (20% down)
            .setTermMonths(360); // 30 years
        return loan;
    }

    /** Creates and returns the sample property being purchased. */
    private static Property createProperty() {
        Property property = new Property();
        property
            .setSalesPrice(300000.0)
            .setAppraisedValue(285000.0)
            .setCostOfLand(220000.0)
            .setLastSoldPrice(200000.0)
            .setLastSoldYear(2000)
            .setStreetAddress("123 Dupont Circle")
            .setCity("Washington")
            .setState("DC")
            .setPostalCode("20009")
            .setYearBuilt(1970);
        return property;
    }

    /** Returns a bogus borrower with good qualifications. */
    private static Borrower createGoodBorrower() {
        Borrower borrower = new Borrower();
        borrower
            .setName("Good Borrower")
            .setSsn("111223333")
            .setCreditScore(800)
            .setFirstTimeBuyer(false)
            .setHasDeclaredBankruptcy(false)
            .setIntendsToOccupy(true)
            .setMonthlyExpenses(1000.0)
            .setMonthlyIncome(2000.0) // Saves $1,000 per month after expenses
            .setTotalAssets(100000.0) // $100,000
            .setTotalLiabilities(0.0);
        return borrower;
    }

    /** Returns a bogus borrower with OK qualifications. */
    private static Borrower createAverageBorrower() {
        Borrower borrower = new Borrower();
        borrower
            .setName("Average Borrower")
            .setSsn("222334444")
            .setCreditScore(700)
            .setFirstTimeBuyer(true)
            .setHasDeclaredBankruptcy(false)
            .setIntendsToOccupy(true)
            .setMonthlyExpenses(4000.0)
            .setMonthlyIncome(4500.0)
            .setTotalAssets(10000.0) // $10,000
            .setTotalLiabilities(20000.0); // $20,000
        return borrower;
    }

    /** Returns a bogus borrower buying the property for investment. */
    private static Borrower createInvestorBorrower() {
        Borrower borrower = new Borrower();
        borrower
            .setName("Investor Borrower")
            .setSsn("333445555")
            .setCreditScore(720)
            .setFirstTimeBuyer(false)
            .setHasDeclaredBankruptcy(false)
            .setIntendsToOccupy(false)
            .setMonthlyExpenses(8000.0)
            .setMonthlyIncome(11000.0) // $11,000
            .setTotalAssets(111000.0) // $111,000
            .setTotalLiabilities(1200000.0); // $1,200,000
        return borrower;
    }

    /** Returns a bogus borrower with some credit riskiness. */
    private static Borrower createRiskyBorrower() {
        Borrower borrower = new Borrower();
        borrower
            .setName("Risk E. Borrower")
            .setSsn("444556666")
            .setCreditScore(520)
            .setFirstTimeBuyer(true)
            .setHasDeclaredBankruptcy(true)
            .setIntendsToOccupy(true)
            .setMonthlyExpenses(4000.0)
            .setMonthlyIncome(4000.0)
            .setTotalAssets(5000.0)
            .setTotalLiabilities(20000.0); // 20,000
        return borrower;
    }

    /** Prints an error message to stderr and exits. */
    private static void printUsageAndExit() {
        System.err.println(
            "Usage: java MortgageScriptRunnerMain <rule directory>"
        );
        System.err.println(
            "    where <rule directory> is the directory containing" +
            " the mortgage rule scripts"
        );
        System.exit(1);
    }
}
