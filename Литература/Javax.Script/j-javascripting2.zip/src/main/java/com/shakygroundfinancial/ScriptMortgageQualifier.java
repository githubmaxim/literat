package com.shakygroundfinancial;

import com.shakygroundfinancial.entities.Borrower;
import com.shakygroundfinancial.entities.Loan;
import com.shakygroundfinancial.entities.Property;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class ScriptMortgageQualifier {

    private ScriptEngineManager scriptEngineManager = new ScriptEngineManager();

    /**
     * Determines whether this borrower/property/loan combination qualifies for
     * the given mortgage according to the mortgage rules in the
     * mortgageRulesFile script.
     * 
     * @return the qualification result as determined by the script
     * @throws FileNotFoundException if the script file can't be read
     * @throws IllegalArgumentException if no script engine has been registered
     *         to handle a file of this type
     * @throws ScriptException if mortgageRulesFile script encounters an error.
     */
    public MortgageQualificationResult qualifyMortgage(
        Borrower borrower, 
        Property property, 
        Loan loan, 
        File mortgageRulesFile
    ) throws FileNotFoundException, IllegalArgumentException, ScriptException 
    {
        ScriptEngine scriptEngine = getEngineForFile(mortgageRulesFile);
        if (scriptEngine == null) {
            throw new IllegalArgumentException(
                "No script engine on classpath to handle file: " + mortgageRulesFile
            );
        }

        // Make params accessible to scripts by adding to engine's context.
        scriptEngine.put("borrower", borrower);
        scriptEngine.put("property", property);
        scriptEngine.put("loan", loan);

        // Make return-value object available to scripts.
        MortgageQualificationResult scriptResult = new MortgageQualificationResult();
        scriptEngine.put("result", scriptResult);
        
        // Add an object scripts can call to exit early from processing.
        scriptEngine.put("scriptExit", new ScriptEarlyExit());
        
        try {
            scriptEngine.eval(new FileReader(mortgageRulesFile));
        } catch (ScriptException se) {
            // Re-throw exception unless it's our early-exit exception.
            // Discovery technique NOT guaranteed to work with all engines!
            if (se.getMessage() == null || 
                !se.getMessage().contains("ScriptEarlyExitException")
            ) {
                throw se;
            }
            // Set script result message if early-exit exception embedded.
            // Will not work with Java 6's included JavaScript engine.
            Throwable t = se.getCause();
            while (t != null) {
                if (t instanceof ScriptEarlyExitException) {
                    scriptResult.setMessage(t.getMessage());
                    break;
                }
                t = t.getCause();
            }
        }
        
        return scriptResult;
    }
    
    /** Returns a script engine based on the extension of the given file. */
    private ScriptEngine getEngineForFile(File f) {
        String fileExtension = getFileExtension(f);
        return scriptEngineManager.getEngineByExtension(fileExtension);
    }
    
    /** Returns the file's extension, or "" if the file has no extension */
    private String getFileExtension(File file) {
        String scriptName = file.getName();
        int dotIndex = scriptName.lastIndexOf('.');

        if (dotIndex != -1) {
            return scriptName.substring(dotIndex + 1);
        } else {
            return "";
        }
    }
    
    
    /** Internal exception so ScriptEarlyExit.exit can exit scripts early */
    private static class ScriptEarlyExitException extends Exception {
        private static final long serialVersionUID = 1L;

        public ScriptEarlyExitException(String msg) {
            super(msg);
        }
    }

    /** Object passed to all scripts so they can indicate an early exit. */
    private static class ScriptEarlyExit {
        public void noMessage() throws ScriptEarlyExitException {
            throw new ScriptEarlyExitException(null);
        }
        public void withMessage(String msg) throws ScriptEarlyExitException {
            throw new ScriptEarlyExitException(msg);
        }
    }
}
